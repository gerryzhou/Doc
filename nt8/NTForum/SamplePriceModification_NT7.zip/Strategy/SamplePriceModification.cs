// 
// Copyright (C) 2007, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//
#region Using declarations
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Indicator;
using NinjaTrader.Strategy;
#endregion

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    /// <summary>
    /// Sample strategy using StopLoss and ProfitTarget orders.
    /// </summary>
    [Description("Sample strategy using StopLoss and ProfitTarget orders.")]
    public class SamplePriceModification : Strategy
    {
        #region Variables
		private int		stoplossticks		= 20;
		private int		profittargetticks	= 100;
        #endregion

        /// <summary>
        /// This method is used to configure the strategy and is called once before any strategy method is called.
        /// </summary>
        protected override void Initialize()
        {
			/* There are several ways you can use SetStopLoss and SetProfitTarget. You can have them set to a currency value
			or some sort of calculation mode. Calculation modes available are by percent, price, and ticks. SetStopLoss and
			SetProfitTarget will submit real working orders unless you decide to simulate the orders. */
			SetStopLoss(CalculationMode.Ticks, stoplossticks);
			SetProfitTarget(CalculationMode.Ticks, profittargetticks);
			
            CalculateOnBarClose = true;
        }

        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
        protected override void OnBarUpdate()
        {
			// Resets the stop loss to the original value when all positions are closed
			if (Position.MarketPosition == MarketPosition.Flat)
			{
				SetStopLoss(CalculationMode.Ticks, stoplossticks);
			}
			
			// If a long position is open, allow for stop loss modification to breakeven
			else if (Position.MarketPosition == MarketPosition.Long)
			{
				// Once the price is greater than entry price+50 ticks, set stop loss to breakeven
				if (Close[0] > Position.AvgPrice + 50 * TickSize)
				{
					SetStopLoss(CalculationMode.Price, Position.AvgPrice);
				}
			}
			
			// Entry Condition: Increasing price along with RSI oversold condition
			if (Close[0] > Close[1] && RSI(14, 3)[0] <= 30)
			{
				EnterLong();
			}			
        }

        #region Properties
		/// <summary>
		/// </summary>
		[Description("Numbers of ticks away from entry price for the Stop Loss order")]
		[Category("Parameters")]
		public int StopLossTicks
		{
			get { return stoplossticks; }
			set { stoplossticks = Math.Max(0, value); }
		}
		
		/// <summary>
		/// </summary>
		[Description("Number of ticks away from entry price for the Profit Target order")]
		[Category("Parameters")]
		public int ProfitTargetTicks
		{
			get { return profittargetticks; }
			set { profittargetticks = Math.Max(0, value); }
		}
        #endregion
    }
}

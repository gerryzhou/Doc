// 
// Copyright (C) 2009, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//
#region Using declarations
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Indicator;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Strategy;
#endregion

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    /// <summary>
    /// This strategy will demonstrate how to limit the number of trades taken per day, and how to reset the trade counter at the beginning of each day.
    /// </summary>
    [Description("This strategy will demonstrate how to limit the number of trades taken per day, and how to reset the trade counter at the beginning of each day.")]
    public class SampleTradeObjects : Strategy
    {
        #region Variables
        private int aDXPeriod 			= 14; 	// Default setting for ADXPeriod
		private int lastThreeTrades 	= 0;  	// This variable holds our value for how profitable the last three trades were.
		private int priorNumberOfTrades = 0;	// This variable holds the number of trades taken. It will be checked every OnBarUpdate() to determine when a trade has closed.
        private int priorSessionTrades	= 0;	// This varialbe holds the number of trades taken prior to each session break.
		#endregion

        /// <summary>
        /// This method is used to configure the strategy and is called once before any strategy method is called.
        /// </summary>
        protected override void Initialize()
        {
			Add(CurrentDayOHL()); // Add the current day open, high, low indicator to visually see entry conditions.
            CalculateOnBarClose = true;
        }

        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
        protected override void OnBarUpdate()
        {
			// Make sure there are enough bars.
			if (CurrentBar < 1)
				return;
			
			// Reset the trade profitablity counter every day and get the number of trades taken in total.
			if (Bars.FirstBarOfSession && FirstTickOfBar)
			{
				lastThreeTrades = 0;
				priorSessionTrades = Performance.AllTrades.Count;
			}
			
			/* Here, Performance.AllTrades.Count - priorSessionTrades checks to make sure there have been three trades today.
			   priorNumberOfTrades makes sure this code block only executes when a new trade has finished. */
			if ((Performance.AllTrades.Count - priorSessionTrades) >= 3 && Performance.AllTrades.Count != priorNumberOfTrades)
			{
				// Reset the counter.
				lastThreeTrades = 0;
				
				// Set the new number of completed trades.
				priorNumberOfTrades = Performance.AllTrades.Count;
				
				// Loop through the last three trades and check profit/loss on each.
				for (int idx = 1; idx <= 3; idx++)
				{
					/* The Performance.AllTrades array stores the most recent trade at the highest index value. If there are a total of 10 trades,
					   this loop will retreive the 10th trade first (at index position 9), then the 9th trade (at 8), then the 8th trade. */
					Trade trade = Performance.AllTrades[Performance.AllTrades.Count - idx];

					/* If the trade's profit is greater than 0, add one to the counter. If the trade's profit is less than 0, subtract one.
						This logic means break-even trades have no effect on the counter. */
					if (trade.ProfitCurrency > 0)
						lastThreeTrades++;
					else if (trade.ProfitCurrency < 0)
						lastThreeTrades--;
				}
			}
			
			/* If lastThreeTrades = -3, that means the last three trades were all losing trades.
			   Don't take anymore trades if this is the case. This counter resets every new session, so it only stops trading for the current day. */
			if (lastThreeTrades != -3)
			{
				if (Position.MarketPosition == MarketPosition.Flat)
				{
					// If a new low is made, enter short
					if (CurrentDayOHL().CurrentLow[0] < CurrentDayOHL().CurrentLow[1])
						EnterShort();
					
					// If a new high is made, enter long
					else if (CurrentDayOHL().CurrentHigh[0] > CurrentDayOHL().CurrentHigh[1])
						EnterLong();
				}
			}
						
			/* Exit a position if "the trend has ended" as indicated by ADX.
			If the current ADX value is less than the previous ADX value, the trend strength is weakening. */
			if (ADX(ADXPeriod)[0] < ADX(ADXPeriod)[1] && Position.MarketPosition != MarketPosition.Flat)
			{
				if (Position.MarketPosition == MarketPosition.Long)
					ExitLong();
				else if (Position.MarketPosition == MarketPosition.Short)
					ExitShort();
			}
        }
        #region Properties
        [Description("Period for the ADX indicator")]
        [Category("Parameters")]
        public int ADXPeriod
        {
            get { return aDXPeriod; }
            set { aDXPeriod = Math.Max(1, value); }
        }
        #endregion
    }
}

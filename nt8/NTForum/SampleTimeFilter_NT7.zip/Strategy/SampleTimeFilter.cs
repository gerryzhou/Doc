// 
// Copyright (C) 2007, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//
#region Using declarations
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Indicator;
using NinjaTrader.Strategy;
#endregion

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
	/// <summary>
	/// Simple moving average cross over strategy.
	/// </summary>
	[Description("Sample strategy using time filter")]
	[Gui.Design.DisplayName("SampleTimeFilter")]
    public class SampleTimeFilter : Strategy
    {
		/// <summary>
		/// This method is used to configure the strategy and is called once before any strategy method is called.
		/// </summary>
        protected override void Initialize()
        {
            CalculateOnBarClose = true;
        }

		/// <summary>
		/// Called on each bar update event (incoming tick).
		/// </summary>
        protected override void OnBarUpdate()
        {
			// Checks to see if the day of the week is Monday or Friday. Only allows trading if the day of the week is not Monday or Friday.
			if (Time[0].DayOfWeek != DayOfWeek.Monday && Time[0].DayOfWeek != DayOfWeek.Friday)
			{
				/* Checks to see if the time is during the busier hours (format is HHMMSS or HMMSS). Only allow trading if current time is during a busy period.
				The timezone used here is (GMT-05:00) EST. */
				if ((ToTime(Time[0]) >= 93000 && ToTime(Time[0]) < 120000) || (ToTime(Time[0]) >= 140000 && ToTime(Time[0]) < 154500))
				{
					// Entry Signal: If current close greater than previous close, enter long
					if (Close[0] > Close[1])
						EnterLong();
				}
			}
			
			// Exit Signal: If position was established at least 5 bars ago, exit long
			if (BarsSinceEntry() > 5)
				ExitLong();
        }
    }
}
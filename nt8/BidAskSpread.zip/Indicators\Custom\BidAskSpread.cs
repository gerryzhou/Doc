#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class BidAskSpread : Indicator
	{
		#region Vars
		private double spread ;
		private string[] yenword ;
		private string name , letter, text;
		private int lettersfound, j, i;
		#endregion
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "BidAskSpread";
				Calculate									= Calculate.OnEachTick;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= false;
				DrawVerticalGridLines						= false;
				PaintPriceMarkers							= false;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				
				AddPlot(new Stroke(Brushes.PaleTurquoise, 2), PlotStyle.Dot, "Bid");
				AddPlot(new Stroke(Brushes.HotPink, 2), PlotStyle.Dot, "Ask");
				AddPlot(new Stroke(Brushes.Transparent,2), PlotStyle.Dot,"spreadSeries");
				IsOverlay				= true;
			}
			else if (State == State.Configure)
			{
				//AddDataSeries(Data.BarsPeriodType.Tick, 1);
			}
		}

		protected override void OnBarUpdate()
		{
			if (State == State.Historical)
				return;
			//if (CurrentBars[1] < 100)
	       	//	return;

			spread = (GetCurrentAsk() - GetCurrentBid());
			//spread = Bars.GetAsk(CurrentBars[1]) - Bars.GetBid(CurrentBars[1]);

			if (Instrument.MasterInstrument.InstrumentType == InstrumentType.Forex)
			{
				yenword = new string[] { "J", "P", "Y" };
				name = Instrument.FullName;
				lettersfound = 0;

				for (j = 0; j < yenword.Length; j++)
				{
					for (i = 0; i < name.Length; i++)
					{
						letter = name[i].ToString();
						if (letter == yenword[j])
							lettersfound++;
					}
				}

				if (lettersfound >= yenword.Length)
				{
					text = (Math.Round((spread * 100), 1).ToString()) + " pip spread";
					//Draw.TextFixed(NinjaScriptBase owner, string tag, string text, TextPosition textPosition, Brush textBrush, SimpleFont font, Brush outlineBrush, Brush areaBrush, int areaOpacity)
					Draw.TextFixed(this, "spread", text, TextPosition.BottomRight, Brushes.Black , new SimpleFont("Arial", 14),  Brushes.Black, Brushes.AntiqueWhite, 100);
					//DrawText("spread", (Math.Round((spread * 100), 1).ToString()) + " pip spread", TextPosition.TopRight, Brushes.Black, new SimpleFont("Arial", 14), Brushes.Black, Brushes.AntiqueWhite, 3);
					spreadSeries[0] = ((Math.Round((spread * 100), 1)));
				}
				else
				{
					text = (Math.Round((spread * 10000), 1).ToString()) + " pip spread";
					Draw.TextFixed(this, "spread", text, TextPosition.BottomRight, Brushes.Black , new SimpleFont("Arial", 14),  Brushes.Black, Brushes.AntiqueWhite, 100);
					//DrawTextFixed("spread", (Math.Round((spread * 10000), 1).ToString()) + " pip spread", TextPosition.TopRight, Color.Black, new Font("Arial", 14), Color.Black, Color.AntiqueWhite, 3);
					spreadSeries[0] = ((Math.Round((spread * 10000), 1)));
				}
			}
			else if (Instrument.MasterInstrument.InstrumentType == InstrumentType.Future)
			{
				text = (Math.Round((spread / TickSize), 1).ToString()) + " tick spread";
				Draw.TextFixed(this, "spread", text, TextPosition.BottomRight, Brushes.Black , new SimpleFont("Arial", 14),  Brushes.Black, Brushes.AntiqueWhite, 100);
				//DrawTextFixed("spread", (Math.Round((spread / TickSize), 1).ToString()) + " tick spread", TextPosition.TopRight, Color.Black, new Font("Arial", 14), Color.Black, Color.AntiqueWhite, 3);
				spreadSeries[0] = ((Math.Round((spread / TickSize), 1)));
			}
			Bid[0] = (GetCurrentBid());
            Ask[0] = (GetCurrentAsk());
			//Bid[0] = Bars.GetBid(CurrentBars[1]);
			//Bars.GetAsk(CurrentBars[1]);
		}

		#region Properties

		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public Series<double> Bid
        {
            get { return Values[0]; }
        }

        [Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public Series<double> Ask
        {
            get { return Values[1]; }
        }
		
        [Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public Series<double> spreadSeries
        {
            get { return Values[2]; }
        }		
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private BidAskSpread[] cacheBidAskSpread;
		public BidAskSpread BidAskSpread()
		{
			return BidAskSpread(Input);
		}

		public BidAskSpread BidAskSpread(ISeries<double> input)
		{
			if (cacheBidAskSpread != null)
				for (int idx = 0; idx < cacheBidAskSpread.Length; idx++)
					if (cacheBidAskSpread[idx] != null &&  cacheBidAskSpread[idx].EqualsInput(input))
						return cacheBidAskSpread[idx];
			return CacheIndicator<BidAskSpread>(new BidAskSpread(), input, ref cacheBidAskSpread);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.BidAskSpread BidAskSpread()
		{
			return indicator.BidAskSpread(Input);
		}

		public Indicators.BidAskSpread BidAskSpread(ISeries<double> input )
		{
			return indicator.BidAskSpread(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.BidAskSpread BidAskSpread()
		{
			return indicator.BidAskSpread(Input);
		}

		public Indicators.BidAskSpread BidAskSpread(ISeries<double> input )
		{
			return indicator.BidAskSpread(input);
		}
	}
}

#endregion

// 
// Copyright (C) 2015, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;


using System.Windows.Automation;
using System.Windows.Automation.Provider;
using System.Windows.Controls;
#endregion

// This namespace holds indicators in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators.Samples
{
	/// <summary>
	/// Shows how to turn on/off the plotting of an EMA via a panel button. USE AT YOUR OWN RISK!!!!!
	/// Currently, based on using 'UserControlCollection' instead of 'ChartControl' as parent, the button appears in the panel where the indicator is located.
	/// This only appears to be a problem when: if used in another lower panel, made invisible, refreshed, then button disappears. This can be eliminated
	/// by adding another indicator in the same panel, such as EMA of a RSI in a lower panel, where the RSI is always visible.
	/// 
	/// simterann22@gmx.com
	/// 
	/// Updated to NT8b9 Mar 2016, Sim22.
	/// </summary>
	public class Sim22_EMAwithButtonV3_2 : Indicator
	{
		private double 			constant1;
		private double 			constant2;
		private List<ColumnDefinition> listColumn;
		//private bool 	useFirstPanelButtonLocation;
		
		///button
		private bool 			installGrid;
		ChartControl 			cc;
		Brush 					buttonBrush;
		SolidColorBrush 		textBrush;
		ChartPanel 				cp;
		Grid					myGrid;
		bool					init;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description					= NinjaTrader.Custom.Resource.NinjaScriptIndicatorDescriptionEMA;
				Name						= "Sim22_EMAwithButtonV3_2";
				IsOverlay					= true;
				IsSuspendedWhileInactive	= true;
				Period						= 50;
				//useFirstPanelButtonLocation	= true;
				
				AddPlot(Brushes.Orange, "ema");
				columnNum					= 1;
				rowNum						= 1;
				buttonText					= " ema";
				installGrid					= true;
				init						= false;
			}
			else if (State == State.Configure)
			{
				constant1 = 2.0 / (1 + Period);
				constant2 = 1 - (2.0 / (1 + Period));
			}
			else if (State == State.Historical)
			{
				cc = this.ChartControl;
				
				if (cc != null)
				{
					cc.Dispatcher.BeginInvoke((Action)(() => //Updated from 'this.Dispatcher.Invoke((Action)(() =>'
					{	
						// find the chart window and subscribe to the tab control selection change event
						Chart myChart = Window.GetWindow(cc.Parent) as Chart;
						if (myChart != null) myChart.MainTabControl.SelectionChanged += MySelectionChangedHandler;
					
						if (installGrid)
						{
						
						foreach (DependencyObject item in myChart.MainMenu)
								{
									if (AutomationProperties.GetAutomationId(item) == "addGrid")
									{
										installGrid = false;
									}
								}
						}
						if (installGrid)
						{
							InstallGrid();
						}
					}));
				}
			}
			else if (State == State.Terminated)
			{
				try
				{
	                if (this.cc != null)
					{
						if (this.UserControlCollection != null)
						{
							this.cc.Children.Remove(myGrid);
							this.UserControlCollection.Remove(myGrid);
							
		                    this.myGrid.Children.Clear();
							this.myGrid = null;
							// unsubscribe
							Chart myChart = Window.GetWindow(cc.Parent) as Chart;
							if (myChart != null) myChart.MainTabControl.SelectionChanged -= MySelectionChangedHandler;
						}
						this.cc = null;
					}
				}
				catch(Exception ex)
				{
					Print(ex.Message.ToString());
				}
            }
		}
		
		public override string DisplayName
		{
			get { return "EMA (" + Period + ")";}
		}

		protected override void OnBarUpdate()
		{
			Value[0] = (CurrentBar == 0 ? Input[0] : Input[0] * constant1 + constant2 * Value[1]);
		}
		
		private void InstallGrid()
		{
			try
			{	
				// Create a grid to house the buttons
				myGrid = new System.Windows.Controls.Grid
		        {
		            Name = "buttonGrid",
		            // Align the control to the top left corner of the chart.
		            HorizontalAlignment = HorizontalAlignment.Left,
		            VerticalAlignment = VerticalAlignment.Top,
		        };
				
				 // Make only as many columns as needed in the grid
				ColumnDefinition[] colDef	= new ColumnDefinition[columnNum];
				
				for (int i = 0; i <= colDef.Length - 1; i++)
				{
					colDef[i]	= new ColumnDefinition();
					colDef[i].Width = new GridLength(45); //60
					myGrid.ColumnDefinitions.Add(colDef[i]);
				}
				
				 
				// Create Rows   
				RowDefinition gridRow1 = new RowDefinition();  
				gridRow1.Height = new GridLength(37);  //37
//				RowDefinition gridRow2 = new RowDefinition();
//				gridRow2.Height = new GridLength(37);
				
				// Set button color to plot color
				buttonBrush = Plots[0].Brush;
				buttonBrush.Freeze();
				
				// Set the text color to white or black depending on the darkness/lightness of the button color
				textBrush = (SolidColorBrush) buttonBrush;
				textBrush = (textBrush.Color.R + textBrush.Color.G + textBrush.Color.B) > 382f ? Brushes.Black : Brushes.White;
				textBrush.Freeze();
				 
				// Format cell text
			    TextBlock txtBlock1 = new TextBlock();  
			    txtBlock1.Text = Period + buttonText;
			    txtBlock1.FontSize = 10;
			    txtBlock1.FontWeight = FontWeights.Bold;  
			    txtBlock1.Foreground = textBrush;
			    txtBlock1.VerticalAlignment = VerticalAlignment.Center; 
				txtBlock1.HorizontalAlignment = HorizontalAlignment.Center;
				
				// Create button 
				Button btn1 = new Button
		         {
		            Name = "Button1",
		            Content = txtBlock1,
		            Foreground = textBrush,
		            Background = buttonBrush,
					HorizontalAlignment = HorizontalAlignment.Center,
					HorizontalContentAlignment = HorizontalAlignment.Center,
					VerticalContentAlignment = VerticalAlignment.Center,
					Margin = new Thickness(1.0,1.0,1.0,1.0),
					BorderBrush = ChartControl.Properties.ChartBackground
		         };
				 btn1.Click += btn_Click;

				// Define where the button should appear in the grid
		        System.Windows.Controls.Grid.SetColumn(btn1, Math.Max(0, colDef.Length));
		        System.Windows.Controls.Grid.SetRow(btn1, Math.Max(0, rowNum - 1)); // set to max 1 at this stage
				
				// Add the button to the grid
				myGrid.Children.Add(btn1);
				// Add the grid to the chart panel
				UserControlCollection.Add(myGrid);
				//cc.Children.Add(myGrid);
				 
				AutomationProperties.SetAutomationId(myGrid, "addGrid");
	           
				this.cc.InvalidateVisual();
			}
			catch(Exception ex)
			{
				Print(ex.Message.ToString());
			}
		}
		/// <summary>
		/// When we click on a new tab, make sure the grid/buttons do not appear on the new tabbed chart
		/// </summary>
		private void MySelectionChangedHandler(object sender, SelectionChangedEventArgs e)
		{
			if (e.AddedItems.Count <= 0)
				return;
						
			ChartTab temp = (e.AddedItems[0] as TabItem).Content as ChartTab;
			if (temp != null)
			{	
				// set grid/button visiblity based on selected tab
				if(myGrid != null)
					myGrid.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
			}
		}	
		/// <summary>
		/// When the button is clicked, make the indicator visible or invisible and refresh the chart
		/// </summary>
        protected void btn_Click(object sender, RoutedEventArgs rea)
        {
			IsVisible = IsVisible == true ? false : true;
			ForceRefresh();
        }
		

		#region Properties
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Period", GroupName = "NinjaScriptParameters", Order = 0)]
		public int Period
		{ get; set; }
		
		[Range(1, 10), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Column #", GroupName = "Button", Order = 1)]
		public int columnNum
		{ get; set; }
		
		//Limited to 1 row at present
		[Range(1, 1), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Row #", GroupName = "Button", Order = 0)]
		public int rowNum
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Button text", GroupName = "Button", Order = 2)]
		public string buttonText
		{ get; set; }
		
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private Samples.Sim22_EMAwithButtonV3_2[] cacheSim22_EMAwithButtonV3_2;
		public Samples.Sim22_EMAwithButtonV3_2 Sim22_EMAwithButtonV3_2(int period, int columnNum, int rowNum, string buttonText)
		{
			return Sim22_EMAwithButtonV3_2(Input, period, columnNum, rowNum, buttonText);
		}

		public Samples.Sim22_EMAwithButtonV3_2 Sim22_EMAwithButtonV3_2(ISeries<double> input, int period, int columnNum, int rowNum, string buttonText)
		{
			if (cacheSim22_EMAwithButtonV3_2 != null)
				for (int idx = 0; idx < cacheSim22_EMAwithButtonV3_2.Length; idx++)
					if (cacheSim22_EMAwithButtonV3_2[idx] != null && cacheSim22_EMAwithButtonV3_2[idx].Period == period && cacheSim22_EMAwithButtonV3_2[idx].columnNum == columnNum && cacheSim22_EMAwithButtonV3_2[idx].rowNum == rowNum && cacheSim22_EMAwithButtonV3_2[idx].buttonText == buttonText && cacheSim22_EMAwithButtonV3_2[idx].EqualsInput(input))
						return cacheSim22_EMAwithButtonV3_2[idx];
			return CacheIndicator<Samples.Sim22_EMAwithButtonV3_2>(new Samples.Sim22_EMAwithButtonV3_2(){ Period = period, columnNum = columnNum, rowNum = rowNum, buttonText = buttonText }, input, ref cacheSim22_EMAwithButtonV3_2);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.Samples.Sim22_EMAwithButtonV3_2 Sim22_EMAwithButtonV3_2(int period, int columnNum, int rowNum, string buttonText)
		{
			return indicator.Sim22_EMAwithButtonV3_2(Input, period, columnNum, rowNum, buttonText);
		}

		public Indicators.Samples.Sim22_EMAwithButtonV3_2 Sim22_EMAwithButtonV3_2(ISeries<double> input , int period, int columnNum, int rowNum, string buttonText)
		{
			return indicator.Sim22_EMAwithButtonV3_2(input, period, columnNum, rowNum, buttonText);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.Samples.Sim22_EMAwithButtonV3_2 Sim22_EMAwithButtonV3_2(int period, int columnNum, int rowNum, string buttonText)
		{
			return indicator.Sim22_EMAwithButtonV3_2(Input, period, columnNum, rowNum, buttonText);
		}

		public Indicators.Samples.Sim22_EMAwithButtonV3_2 Sim22_EMAwithButtonV3_2(ISeries<double> input , int period, int columnNum, int rowNum, string buttonText)
		{
			return indicator.Sim22_EMAwithButtonV3_2(input, period, columnNum, rowNum, buttonText);
		}
	}
}

#endregion

#region Using declarations
using NinjaTrader.Gui;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Media;
using System.Xml.Serialization;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
    public class TwiggsMoneyFlow : Indicator
    {
        private int tMFPeriods = 5; // Default setting for TMFPeriods
        private double trueHigh;
        private double trueLow;
        private double trueRange;
        private double sub;
        private double len;
        private Series<double> aDV;

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"Twiggs Money Flow as introduced by Mr. Colin Twiggs";
                Name = "TwiggsMoneyFlow";
                //Calculate									= Calculate.OnBarClose;
                IsOverlay = false;
                DisplayInDataBox = true;
                DrawOnPricePanel = true;
                DrawHorizontalGridLines = true;
                DrawVerticalGridLines = true;
                PaintPriceMarkers = true;
                ScaleJustification = NinjaTrader.Gui.Chart.ScaleJustification.Right;
                //Disable this property if your indicator requires custom values that cumulate with each new market data event. 
                //See Help Guide for additional information.
                IsSuspendedWhileInactive = true;
                TMFPeriods = 5;

                AddPlot(Brushes.DodgerBlue, "Up1");
                AddPlot(new Stroke(Brushes.DodgerBlue, 2), PlotStyle.Bar, "Up2");
                AddPlot(Brushes.IndianRed, "Dn1");
                AddPlot(new Stroke(Brushes.IndianRed, 2), PlotStyle.Bar, "Dn2");
                AddLine(Brushes.Yellow, 0, "Zero");

                aDV = new Series<double>(this);

                //set min and max for the respective plot values
                Plots[0].Min = 0;
                Plots[1].Min = 0;
                Plots[2].Max = 0;
                Plots[3].Max = 0;


            }
            else if (State == State.Configure)
            {
            }
        }

        protected override void OnBarUpdate()
        {
            len = tMFPeriods * 1.8;

            //make sure we have enough bars progressed
            if (CurrentBar < tMFPeriods)
                return;

            //define the true high
            if (Close[1] > High[0])
                trueHigh = Close[1];
            else
                trueHigh = High[0];

            //define the true low
            if (Close[1] < Low[0])
                trueLow = Close[1];
            else
                trueLow = Low[0];

            //calculate the true range
            trueRange = trueHigh - trueLow;

            //calculate close to true high / true low differences
            sub = ((Close[0] - trueLow) - (trueHigh - Close[0]));

            //check for cases where true range is zero, if not calculate the adv value
            if (trueRange == 0)
                aDV[0] = ((sub / 999999) * Volume[0]);
            else
                aDV[0] = ((sub / trueRange) * Volume[0]);

            //check for cases where the ema returns zero, if yes display zero value
            if (EMA(Volume, tMFPeriods)[0] == 0)
            {
                Up1[0] = (0);
                Up2[0] = (0);
                Dn1[0] = (0);
                Dn2[0] = (0);
            }
            else
            {
                // else calculate the final smoothed tmf indicator value 
                double value2 = EMA(aDV, tMFPeriods)[0];
                double value3 = EMA(Volume, tMFPeriods)[0];

                Up1[0] = (value2 / value3);
                Up2[0] = (value2 / value3);
                Dn1[0] = (value2 / value3);
                Dn2[0] = (value2 / value3);
            }
        }

        #region Properties
        [NinjaScriptProperty]
        [Display(Name = "TMFPeriods", Description = "Calculation Periods for TMF", Order = 1, GroupName = "Parameters")]
        public int TMFPeriods
        {
            get { return tMFPeriods; }
            set { tMFPeriods = Math.Max(3, value); }
        }

        [Browsable(false)]
        [XmlIgnore]
        public Series<double> Up1
        {
            get { return Values[0]; }
        }

        [Browsable(false)]
        [XmlIgnore]
        public Series<double> Up2
        {
            get { return Values[1]; }
        }

        [Browsable(false)]
        [XmlIgnore]
        public Series<double> Dn1
        {
            get { return Values[2]; }
        }

        [Browsable(false)]
        [XmlIgnore]
        public Series<double> Dn2
        {
            get { return Values[3]; }
        }

        #endregion

    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private TwiggsMoneyFlow[] cacheTwiggsMoneyFlow;
		public TwiggsMoneyFlow TwiggsMoneyFlow(int tMFPeriods)
		{
			return TwiggsMoneyFlow(Input, tMFPeriods);
		}

		public TwiggsMoneyFlow TwiggsMoneyFlow(ISeries<double> input, int tMFPeriods)
		{
			if (cacheTwiggsMoneyFlow != null)
				for (int idx = 0; idx < cacheTwiggsMoneyFlow.Length; idx++)
					if (cacheTwiggsMoneyFlow[idx] != null && cacheTwiggsMoneyFlow[idx].TMFPeriods == tMFPeriods && cacheTwiggsMoneyFlow[idx].EqualsInput(input))
						return cacheTwiggsMoneyFlow[idx];
			return CacheIndicator<TwiggsMoneyFlow>(new TwiggsMoneyFlow(){ TMFPeriods = tMFPeriods }, input, ref cacheTwiggsMoneyFlow);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.TwiggsMoneyFlow TwiggsMoneyFlow(int tMFPeriods)
		{
			return indicator.TwiggsMoneyFlow(Input, tMFPeriods);
		}

		public Indicators.TwiggsMoneyFlow TwiggsMoneyFlow(ISeries<double> input , int tMFPeriods)
		{
			return indicator.TwiggsMoneyFlow(input, tMFPeriods);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.TwiggsMoneyFlow TwiggsMoneyFlow(int tMFPeriods)
		{
			return indicator.TwiggsMoneyFlow(Input, tMFPeriods);
		}

		public Indicators.TwiggsMoneyFlow TwiggsMoneyFlow(ISeries<double> input , int tMFPeriods)
		{
			return indicator.TwiggsMoneyFlow(input, tMFPeriods);
		}
	}
}

#endregion

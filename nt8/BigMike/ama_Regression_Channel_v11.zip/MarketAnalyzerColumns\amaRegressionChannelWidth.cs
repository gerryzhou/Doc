#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
#endregion

//This namespace holds MarketAnalyzerColumns in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	[Gui.CategoryOrder("Input Parameters", 10)]
	[Gui.CategoryOrder("Data Series", 30)]
	[Gui.CategoryOrder("Set up", 40)]
	[Gui.CategoryOrder("Time frame", 50)]
	[Gui.CategoryOrder("Visual", 60)]
	[Gui.CategoryOrder("Conditions", 70)]
	public class amaRegressionChannelWidth : MarketAnalyzerColumn
	{
		private NinjaTrader.NinjaScript.Indicators.LizardIndicators.amaRegressionChannel amaRC;
		
		private int				regressionPeriod			= 50;
		private int				barsAgo						= 0;
		private double			multiplier					= 3.5;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"";
				Name										= "amaRegressionChannel_Width";
				Calculate									= Calculate.OnPriceChange;
				DataType   									= typeof(double);
        		IsEditable 									= false;
				FormatDecimals 								= 1;
			}
			else if (State == State.DataLoaded)
			{
				amaRC		= 	amaRegressionChannel(regressionPeriod, multiplier, barsAgo);
			}
		}
		
		protected override void OnMarketData(MarketDataEventArgs marketDataUpdate)
		{
		  if (marketDataUpdate.MarketDataType == MarketDataType.Last)
		  	CurrentValue = amaRC.NormalizedChannelWidth[0];
		}
		
		#region Properties
		[Range(2, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Regression period", Description = "Select lookback period for linear regression", GroupName = "Input Parameters", Order = 0)]
		public int RegressionPeriod
		{	
            get { return regressionPeriod; }
            set { regressionPeriod = value; }
		}

		[Range(0, double.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Std. dev. multiplier", Description = "Select standard deviation multiplier for linear regression channel", GroupName = "Input Parameters", Order = 1)]
		public double Multiplier
		{	
            get { return multiplier; }
            set { multiplier = value; }
		}
		
		[Range(0, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Calculated bars ago", Description = "Select last bar used for calculating the regression channel", GroupName = "Input Parameters", Order = 2)]
      	[RefreshProperties(RefreshProperties.All)] 
		public int BarsAgo
		{	
            get { return barsAgo; }
            set { barsAgo = value; }
		}
		#endregion
	}
}

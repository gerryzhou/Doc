#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion
/// Coded by Zondor for efficient operation, Adapted for Ninjatrader 8, 20 October 2014
/// revision A 02 November 2015    corrected excessively long period of invalid outputs after startup
//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.MovingAverages
{
	public class MESA_AMA : Indicator
	{   
        private double []          i2,q2;
		private double[]           detrender;
		private double[]           smooth;
        private double[]           q1;
		private double[]           i1;
		private double[]           imaginary;
		private double[]           real;
		private double[]           period_;
		private double			   fastLimit;
		private double			   slowLimit;
		private double             prevInput, jI, jQ;
		private double             dt246=0,  i_28=0,   q_28=0,   r_28=0,   m_28=0;
		private double             s32=0,    d246=0,   p17=0,    i_16=0,   q_16=0,  j_16=0;
		private double             alpha,    deltaPhase;
	  	private double             phase_1=0,       phase_0=0;
		private double             TwoPi;
		private double             InvPi;
		
		private DateTime LR;
		
		private bool FirstTick=true;
		private int barcount;
		private int RD;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description							= @"MESA Adaptive Moving Average (per John Ehlers)";
				Name								= "MESA AMA";
				Calculate							= Calculate.OnPriceChange;
				IsOverlay							= true;
				DisplayInDataBox					= true;
				DrawOnPricePanel					= true;
				DrawHorizontalGridLines				= true;
				DrawVerticalGridLines				= true;
				PaintPriceMarkers					= true;
				ScaleJustification					= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				
				IsSuspendedWhileInactive			= true;
				AddPlot(Brushes.Cyan, "MESA ma");
				Plots[0].Width=3;
			    AddPlot(Brushes.Gray, "FAMA");
				Plots[0].Width=1;
				FastLimit=0.40;
				SlowLimit=0.025;
				BarUpBrush=Brushes.Green;
				BarDnBrush=Brushes.Red;
			}
			else if (State == State.Configure)
			{   detrender 						  =new double[7];
				smooth   						  =new double[7];
				q1        						  =new double[7];
				i1        						  =new double[7];
				q2        						  =new double[7];
				i2       						  =new double[7];	
				imaginary						  =new double[2];
			    real     						  =new double[2];
				period_							  =new double[2];
				TwoPi							  =Math.Round(2*Math.PI,6);
				InvPi							  =Math.Round(180 / Math.PI,6);
				fastLimit						  =FastLimit;
				slowLimit						  =SlowLimit;
				BarUpBrush.Freeze();
				BarDnBrush.Freeze();
				Print("Thank you for using MESA AMA... you are soooo awesome!");
			}
			
			else if (State==State.Terminated)
			{   
				Print("bye bye from MESA AMA... you are soooo awesome!");
			}
		}

		protected override void OnBarUpdate()
		{
			try{
			//if (CurrentBar < 4)
			//{	Values[0][0]=(.50*(High[0] + Low[0]) / 2);Values[1][0]=Values[0][0];return; }
			
		if(IsFirstTickOfBar )
		{
			prevInput=Input[0];
			if(IsFirstTickOfBar &&CurrentBar>2)
			{	int count;
				
				for( count =6;count>0;count--)
				 {
					detrender[count]=detrender[count-1];
				    smooth[count]=smooth[count-1];
					q1[count]=q1[count-1];
					i1[count]=i1[count-1];
			     }
				#region ~ new bar calculations ~
				imaginary[1]=imaginary[0]; real[1]=real[0];period_[1]=period_[0];
				i2[1]=i2[0]; q2[1]=q2[0]; period_[1]=period_[0]; phase_1=phase_0;
				s32=3 * Median[1] + 2 * Median[2] + Median[3];
				d246=  + 0.5769 * smooth[2] - 0.5769 * smooth[4] - 0.0962 * smooth[6];
				p17=0.075*period_[1] + 0.54;
				i_16= + 0.5769 * i1[2] - 0.5769 * i1[4] - 0.0962 * i1[6];
				j_16= + 0.5769 * q1[2] - 0.5769 * q1[4] - 0.0962 * q1[6];
				dt246=+ 0.5769 * detrender[2] - 0.5769 * detrender[4] - 0.0962 * detrender[6];
				//i_28=0.8 * i2[1]; 	q_28=0.8 * q2[1];  	r_28=0.8 * re[1];  	m_28=0.8 * im[1];
				i_28=0.8 * i2[0]; 	q_28=0.8 * q2[0];  	r_28=0.8 * real[0];  	m_28=0.8 * imaginary[0];
			    #endregion
				 
				Values[0][0]=Values[0][1]; Values[1][0]=Values[1][1];
			}
			if(ChartControl==null || IsFirstTickOfBar || (Input[0] != prevInput && Time[0]>LR.AddMilliseconds(100)))
				{
				prevInput=Input[0];
				smooth[0]=(4 * Median[0] + s32) / 10;
				
				detrender[0]=(0.0962 * smooth[0] + d246) * (p17);

				// Compute InPhase and Quadrature components
				
	            q1[0]=(0.0962 * detrender[0] + dt246) * (p17);
				i1[0]=detrender[3];

				// Advance the phase of i1 and q1 by 90}
				
				  jI = (0.0962 * i1[0] + i_16) * (p17);
				  jQ = (0.0962 * q1[0] + j_16) * (p17);

				// Phasor addition for 3 bar averaging}			
					i2[0]=i1[0] - jQ;			
	                q2[0]=q1[0]  +jI;
					
				// Smooth the I and Q components before applying the discriminator		
					i2[0]=0.2 * i2[0] + i_28;			
	                q2[0]= 0.2*q2[0] + q_28;
					i_28=0.8 * i2[0]; 	q_28=0.8 * q2[0];  	r_28=0.8 * real[0];  	m_28=0.8 * imaginary[0];  
					
				// Homodyne Discriminator
				real[0]      =(i2[0] * i2[1] + q2[0] * q2[1]);
				imaginary[0] =(i2[0] * q2[1] - q2[0] * i2[1]);

				real[0]=(0.2 * real[0] + r_28);
				imaginary[0]=(0.2 * imaginary[0] + m_28);

				
				if (imaginary[0] != 0.0 && real[0] != 0.0) period_[0] = (TwoPi / ( System.Math.Atan(imaginary[0] / real[0])));
				if (period_[0] > 1.5  * period_[1]) period_[0]=(1.5  * period_[1]);
				if (period_[0] < 0.67 * period_[1]) period_[0]=(0.67 * period_[1]);
				
				
	            period_[0]=  Math.Min( Math.Max(period_[0],6),50) ;  
				period_[0]=  (0.2 * period_[0] + 0.8 * period_[1]);

				if (i1[0] != 0.0) phase_0 = InvPi * System.Math.Atan(q1[0] / i1[0]);

				deltaPhase =Math.Max(1, phase_1 - phase_0);
				alpha = Math.Max(slowLimit, fastLimit / deltaPhase);
				
				// MAMA
				
                if(CurrentBar<8)Values[0][0]=Close[0]; // rev A
				else
				Values[0][0]=alpha * Median[0] + (1 - alpha) * Values[0][1];	
				// FAMA
				if(CurrentBar<9)Values[1][0]=Close[0]; // rev A
				else
				Values[1][0]=.5 * alpha * Values[0][0] + (1 - 0.5 * alpha) * Values[1][1];
				  if(CurrentBar>10)
				  {
			          if( Values[0][0]<Weighted[0]) PlotBrushes[0][0]=BarUpBrush;
					 else if( Values[0][0]>Weighted[0]) PlotBrushes[0][0]=BarDnBrush;
					 else PlotBrushes[0][0]=Plots[0].Brush;
				  }
				}
			if(State==State.Realtime)LR=Time[0];
			}	
		
		}catch (Exception e)	{Print("Bar "+CurrentBar+": MA, MESA Line 171 " + e.ToString());return;}
		}
		
		[Range(0.05, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "FastLimit", GroupName = "NinjaScriptParameters", Order = 0)]
		public double FastLimit
		{ get; set; }

		[Range(0.005, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "SlowLimit", GroupName = "NinjaScriptParameters", Order = 1)]
		public double SlowLimit
		{ get; set; }
		
		
			[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Up BarColor", Order = 6, GroupName = "NinjaScriptParameters")]
		public Brush BarUpBrush		
		{ get; set; }
			
		[Browsable(false)]
		public string BarUpBrushSerialize
		{
			get { return Serialize.BrushToString(BarUpBrush); }
   			set { BarUpBrush = Serialize.StringToBrush(value); }
		}
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Dn BarColor", Order = 6, GroupName = "NinjaScriptParameters")]
		public Brush BarDnBrush
		{ get; set; }
		
		[Browsable(false)]
		public string BarDnBrushSerialize
		{
			get { return Serialize.BrushToString(BarDnBrush); }
   			set { BarDnBrush = Serialize.StringToBrush(value); }
		}
	}
	
	
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private MovingAverages.MESA_AMA[] cacheMESA_AMA;
		public MovingAverages.MESA_AMA MESA_AMA(double fastLimit, double slowLimit)
		{
			return MESA_AMA(Input, fastLimit, slowLimit);
		}

		public MovingAverages.MESA_AMA MESA_AMA(ISeries<double> input, double fastLimit, double slowLimit)
		{
			if (cacheMESA_AMA != null)
				for (int idx = 0; idx < cacheMESA_AMA.Length; idx++)
					if (cacheMESA_AMA[idx] != null && cacheMESA_AMA[idx].FastLimit == fastLimit && cacheMESA_AMA[idx].SlowLimit == slowLimit && cacheMESA_AMA[idx].EqualsInput(input))
						return cacheMESA_AMA[idx];
			return CacheIndicator<MovingAverages.MESA_AMA>(new MovingAverages.MESA_AMA(){ FastLimit = fastLimit, SlowLimit = slowLimit }, input, ref cacheMESA_AMA);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.MovingAverages.MESA_AMA MESA_AMA(double fastLimit, double slowLimit)
		{
			return indicator.MESA_AMA(Input, fastLimit, slowLimit);
		}

		public Indicators.MovingAverages.MESA_AMA MESA_AMA(ISeries<double> input , double fastLimit, double slowLimit)
		{
			return indicator.MESA_AMA(input, fastLimit, slowLimit);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.MovingAverages.MESA_AMA MESA_AMA(double fastLimit, double slowLimit)
		{
			return indicator.MESA_AMA(Input, fastLimit, slowLimit);
		}

		public Indicators.MovingAverages.MESA_AMA MESA_AMA(ISeries<double> input , double fastLimit, double slowLimit)
		{
			return indicator.MESA_AMA(input, fastLimit, slowLimit);
		}
	}
}

#endregion

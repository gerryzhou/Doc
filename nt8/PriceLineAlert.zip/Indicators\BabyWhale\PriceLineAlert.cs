#region Using declarations

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Windows.Media;
using NinjaTrader.Core;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.NinjaScript;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.NinjaScript.Indicators.BabyWhale;
using SharpDX;
using SharpDX.DirectWrite;
using Color = SharpDX.Color;

#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.BabyWhale
{
    public enum PriceState
    {
        Unknown,
        Below, 
        Above
    }
    public class LineInfo
    {
        public double Price { get; set; }
        public PriceState State { get; set; }
    }


    public class PriceLineAlert : Indicator
    {
        List<LineInfo> _lines = new List<LineInfo>();
        public enum PositionEnum
        {
            Below,
            Above
        }

        public enum SideEnum
        {
            Left,
            Right
        }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"Plays an alert when price crosses a horizontal line.";
                Name = "PriceLineAlert";
                Calculate = Calculate.OnPriceChange;
                IsOverlay = true;
                DisplayInDataBox = true;
                DrawOnPricePanel = true;
                DrawHorizontalGridLines = true;
                DrawVerticalGridLines = true;
                PaintPriceMarkers = true;
                ScaleJustification = ScaleJustification.Right;
                IsSuspendedWhileInactive = true;
                Side = SideEnum.Right;
                Size = 10;
                Position = PositionEnum.Above;
                Bold = true;
                Opacity = 180;
                _lines = new List<LineInfo>();
            }
            else if (State == State.Configure)
            {
            }
        }


        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
            var pricesFound = new List<double>();
            foreach (var co in ChartControl.ChartObjects)
            {
                if (co is HorizontalLine)
                {
                    var l1 = co as HorizontalLine;
                    var priceformat = Globals.GetTickFormatString(TickSize);

                    float x, y;

                    var col = ((SolidColorBrush)ChartControl.Properties.ChartBackground).Color;
                    using (var backbr = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, new Color { A = Opacity, R = col.R, G = col.G, B = col.B }))
                    using (var br = l1.Stroke.Brush.ToDxBrush(RenderTarget))
                    using (var factory = new Factory(FactoryType.Shared))
                    using (var textFormat = new TextFormat(factory, "Arial", Bold ? FontWeight.Bold : FontWeight.Normal, FontStyle.Normal, Size * 96 / 72))
                    {
                        var price = l1.Anchors.First().Price;
                        pricesFound.Add(price);
                        var text = l1.Anchors.First().Price.ToString(priceformat);
                        using (var textLayout = new TextLayout(factory, text, textFormat, float.MaxValue, float.MaxValue))
                        {
                            if (Side == SideEnum.Right)
                            {
                                x = ChartPanel.W - textLayout.Metrics.Width;
                            }
                            else
                            {
                                x = 0;
                            }

                            y = chartScale.GetYByValue(l1.Anchors.First().Price);

                            if (Position == PositionEnum.Above)
                            {
                                y -= textLayout.Metrics.Height + l1.Stroke.Width / 2.0f;
                            }
                            else
                            {
                                y += l1.Stroke.Width / 2.0f;
                            }

                            RenderTarget.FillRectangle(new RectangleF(x, y, textLayout.Metrics.Width, textLayout.Metrics.Height), backbr);
                            RenderTarget.DrawText(text, textFormat, new RectangleF(x, y, textLayout.Metrics.Width, textLayout.Metrics.Height), br);
                        }
                    }
                }
            }

            var newList = new List<LineInfo>();
            foreach (var price in pricesFound)
            {
                var info = _lines.FirstOrDefault(e => e.Price == price);
                if (info == null)
                {
                    info = new LineInfo { Price = price, State = PriceState.Unknown };
                }
                newList.Add(info);
            }

            _lines = newList;
            double currentAsk = GetCurrentAsk();
            foreach (var info in _lines)
            {
                if (currentAsk > info.Price)
                {
                    // price is above the line
                    if (info.State == PriceState.Below)
                    {
                        PlaySound(NinjaTrader.Core.Globals.InstallDir + @"\sounds\Alert1.wav");
                    }
                    info.State = PriceState.Above;
                }
                else
                {
                    // price is above the line
                    if (info.State == PriceState.Above)
                    {
                        PlaySound(NinjaTrader.Core.Globals.InstallDir + @"\sounds\Alert1.wav");
                    }
                    info.State = PriceState.Below;
                }
            }
        }

        #region Properties

        [Display(Name = "Font Size", GroupName = "Settings", Order = 0)]
        public int Size { get; set; }

        [Display(Name = "Bold", GroupName = "Settings", Order = 1)]
        public bool Bold { get; set; }

        [Display(Name = "Side", GroupName = "Settings", Order = 2)]
        public SideEnum Side { get; set; }

        [Display(Name = "Position", GroupName = "Settings", Order = 3)]
        public PositionEnum Position { get; set; }

        [Display(Name = "BackGround Opacity(0-255)", GroupName = "Settings", Order = 4)]
        public byte Opacity { get; set; }

        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private BabyWhale.PriceLineAlert[] cachePriceLineAlert;
		public BabyWhale.PriceLineAlert PriceLineAlert()
		{
			return PriceLineAlert(Input);
		}

		public BabyWhale.PriceLineAlert PriceLineAlert(ISeries<double> input)
		{
			if (cachePriceLineAlert != null)
				for (int idx = 0; idx < cachePriceLineAlert.Length; idx++)
					if (cachePriceLineAlert[idx] != null &&  cachePriceLineAlert[idx].EqualsInput(input))
						return cachePriceLineAlert[idx];
			return CacheIndicator<BabyWhale.PriceLineAlert>(new BabyWhale.PriceLineAlert(), input, ref cachePriceLineAlert);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.BabyWhale.PriceLineAlert PriceLineAlert()
		{
			return indicator.PriceLineAlert(Input);
		}

		public Indicators.BabyWhale.PriceLineAlert PriceLineAlert(ISeries<double> input )
		{
			return indicator.PriceLineAlert(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.BabyWhale.PriceLineAlert PriceLineAlert()
		{
			return indicator.PriceLineAlert(Input);
		}

		public Indicators.BabyWhale.PriceLineAlert PriceLineAlert(ISeries<double> input )
		{
			return indicator.PriceLineAlert(input);
		}
	}
}

#endregion
